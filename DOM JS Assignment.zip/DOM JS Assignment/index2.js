document.getElementById('registrationForm').addEventListener('submit',
    function (clickedevent) {
        clickedevent.adddetails();
    });


let containerinfo = [];

function adddetails() {
    const studentName = document.getElementById('studentName').value;
    const studentID = document.getElementById('studentID').value;
    const emailId = document.getElementById('emailID').value;
    const contactNo = document.getElementById('contactNo').value;

    const details = {
        name: studentName,
        id: studentID,
        email: emailId,
        contact: contactNo
    }

    details.push(containerinfo);
    createtable();
}
// if (adddetails === true) {
//     console.log("Event called");
// }

function createtable() {
    const tablebody = document.querySelector('#studentRecords tbody');
    tablebody.innerHTML = '';

    containerinfo.forEach(function (details, indexofeachdata) {
        const row = document.createElement('tr');
        row.innerHTML = `<td>${details.name}</td><td>${details.id}</td><td>${details.email}</td><td>${details.contact}</td>
        <td>
        <button class = "fas fa-edit" onClick = "editdetails(${indexofeachdata})"></button>
        </td>
        <td>
        <button class = "fa-solid fa-trash" onClick = "deletedetails(${indexofeachdata})"></button>
        </td>`;

        tablebody.appendChild(row);
    });
}

function editdetails(dataofedit) {
    const detailsforedit = details[dataofedit];

    document.getElementById('studentName').value = detailsforedit.name;
    document.getElementById('studentID').value = detailsforedit.id;
    document.getElementById('emailID').value = detailsforedit.email;
    document.getElementById('contactNo').value = detailsforedit.contact;

    deletedetails(dataofedit);
}

function deletedetails(dataofedit) {
    details.splice(dataofedit, 1);
    createtable();
}
createtable();

