let students = [];

document.getElementById('registrationForm').addEventListener('submit', function (event) {
    event.preventDefault();
    addStudent();
});

function addStudent() {

    const studentName = document.getElementById('studentName').value;
    const studentID = document.getElementById('studentID').value;
    const emailID = document.getElementById('emailID').value;
    const contactNo = document.getElementById('contactNo').value;

    if (!studentName || !studentID || !emailID || !contactNo) {
        alert('All fields are required.');
        return;
    }

    const student = {
        name: studentName,
        id: studentID,
        email: emailID,
        contact: contactNo
    };

    students.push(student);
    displayStudents();
}

function displayStudents() {
    const tbody = document.querySelector('#studentRecords tbody');
    tbody.innerHTML = '';

    students.forEach((student, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${student.name}</td>
            <td>${student.id}</td>
            <td>${student.email}</td>
            <td>${student.contact}</td>
            <td>
                <button class="fas fa-edit" onclick="editStudent(${index})"></button>
                <button class="fa-solid fa-trash" onclick="deleteStudent(${index})"></button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function editStudent(index) {
    const student = students[index];

    document.getElementById('studentName').value = student.name;
    document.getElementById('studentID').value = student.id;
    document.getElementById('emailID').value = student.email;
    document.getElementById('contactNo').value = student.contact;

    deleteStudent(index);
}

function deleteStudent(index) {
    students.splice(index, 1);
    displayStudents();
}
displayStudents();
